import os
from pyspark import SparkConf
from pyspark.sql import SparkSession
import logging
import logging.config

def get_spark_object(appName):
    spark = None
    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .getOrCreate()

    except NameError as exp:
        logging.error("NameError in the method - get_spark_object(). Please check the Stack Trace. " + str(exp), exc_info=True)
        raise
    except Exception as exp:
        logging.error("Error in the method - get_spark_object(). Please check the Stack Trace. " + str(exp), exc_info=True)
    else:
        logging.info("Spark Object is created ")

    return spark