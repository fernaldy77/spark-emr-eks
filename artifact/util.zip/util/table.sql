create table agg_hvghs_trip (
    date_partition date,
    hvfhs_license_num varchar,
    PULocationID varchar,
    total_fare int,
    count_trip int,
    primary key(date_partition, hvfhs_license_num, PULocationID)
);

create table agg_fhv_trip (
    date_partition date,
    dispatching_base_num varchar,
    PUlocationID varchar,
    DOlocationID varchar,
    count_trip int,
    primary key(date_partition, dispatching_base_num, PUlocationID, DOlocationID)
);